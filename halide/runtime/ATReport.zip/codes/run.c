#include <stdio.h>

extern "C" int halide_opencl_device_release(void *user_context) {                          
	//Finish application
	printf("Override!\n");
}
