#include <Halide.h>
#include <stdio.h>
using namespace Halide;

int main(int argc, char* argv[]){

	ImageParam input_image(type_of<uint8_t>(),3);

	Func blur, input;
	Var x("x"), y("y"), c("c");
	
	//Algorithm
	input(x,y,c) = cast<float>(input_image(x,y,c));
	blur(x,y,c) = 
		( input(x-1,y-1,c) + input(x,y-1,c) + input(x+1,y-1,c)
		  + input(x-1,y,c) + input(x,y,c) + input(x+1,y,c)
		  + input(x-1,y+1,c) + input(x,y+1,c) + input(x+1,y+1,c) )/9;

	//Schedule
	blur.compute_root();
	
	//Compilation
	std::vector<Argument> args = {input_image};
	blur.compile_to_file("blur", args);

	return 0;
}
