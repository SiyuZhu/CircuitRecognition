#include "./blur.h"
#include <stdio.h>
#include <stdlib.h>

#define INPUT_X 1024
#define INPUT_Y 1024
#define INPUT_C 2

#define OUTPUT_X (INPUT_X-2)
#define OUTPUT_Y (INPUT_Y-2)
#define OUTPUT_C INPUT_C

int main(){

	uint8_t *input_image = (uint8_t*)malloc(sizeof(uint8_t)*INPUT_X*INPUT_Y*INPUT_C);

	for (int c = 0; c < INPUT_C; c++) {
		for (int y = 0; y < INPUT_Y; y++) {
			for (int x = 0; x < INPUT_X; x++) {
				if ( (y & 0x1) == 0x1 ) {
					input_image[c*INPUT_X*INPUT_Y + y*INPUT_X + x] = 0;
				} else if ( (y & 0x1) == 0x0 ) {
					input_image[c*INPUT_X*INPUT_Y + y*INPUT_X + x] = 3;
				}
			}
		}
	}

	uint8_t *output = (uint8_t *)malloc(sizeof(uint8_t)*OUTPUT_X*OUTPUT_Y*OUTPUT_C);

	buffer_t input_buf = {0}, output_buf = {0};

	input_buf.host = input_image;
	output_buf.host = (uint8_t*)output;

	input_buf.stride[0] = 1;
	input_buf.stride[1] = INPUT_X;
	input_buf.stride[2] = INPUT_X*INPUT_Y;
	
	input_buf.extent[0] = INPUT_X;
	input_buf.extent[1] = INPUT_Y;
	input_buf.extent[2] = INPUT_C;
	
	input_buf.min[0] = 0;
	input_buf.min[1] = 0;
	input_buf.min[2] = 0;
	
	output_buf.stride[0] = 1;
	output_buf.stride[1] = OUTPUT_X;
	output_buf.stride[2] = OUTPUT_X*OUTPUT_Y;
	
	output_buf.extent[0] = OUTPUT_X;
	output_buf.extent[1] = OUTPUT_Y;
	output_buf.extent[2] = OUTPUT_C;
	
	output_buf.min[0] = 1;
	output_buf.min[1] = 1;
	output_buf.min[2] = 0;

	input_buf.elem_size = sizeof(uint8_t);
	output_buf.elem_size = sizeof(uint8_t);

	input_buf.host_dirty = true;

	int error = blur(&input_buf,&output_buf);
	
	printf("Success!\n");
	return 0;
}
